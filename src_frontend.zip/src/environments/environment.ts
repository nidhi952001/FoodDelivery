export const environment = {
    production: false,
    apiUrl:
      'https://demo.codingbirdsonline.com/country-state-city-dropdown-api/index.php?endpoint=', // you can change your localhost path for api.
  };