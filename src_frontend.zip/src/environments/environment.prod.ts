export const environment = {
    production: true,
    apiUrl:
      'https://demo.codingbirdsonline.com/country-state-city-dropdown-api/index.php?endpoint=',
  };