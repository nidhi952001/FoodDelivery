export class Admin {
    constructor(
        public adminid:number,
        public username:string,
        public password:string
    ){}
}
