export class DummyPayment {
    public static  personName:string="Nidhi";
    public static cardNum:string = "915726688591";
    public static expiryDate:string = "09/2023";
    public static cvv:any="123";
}
