export class CustomerAddress {
    constructor(
        public addressid:number,
        public area:string,
        public city:string,
        public state:string,
        public country:string,
        public pincode:number
    ){  }

}
